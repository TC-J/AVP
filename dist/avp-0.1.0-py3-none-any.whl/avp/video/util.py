import cv2

class Camera:
    def __init__(self):
        pass