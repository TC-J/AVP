import sys

from avp.gui.application import AVPApplication

from PyQt6.QtWidgets import (
    QWidget
)



def main():
    application = AVPApplication(app=AVPApplication(sys.argv), scale=0.9)

    application.render()

    sys.exit(application.execute())

