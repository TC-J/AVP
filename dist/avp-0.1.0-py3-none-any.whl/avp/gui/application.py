from sys import argv, stdout

from typing import TextIO

from PyQt6.QtCore import (
    QObject,
    QEvent
)

from PyQt6.QtGui import (
    QScreen
)

from PyQt6.QtWidgets import (
    QApplication, 
    QMainWindow, 
    QWidget
)


class AVPApplication(QApplication, QMainWindow):
    """The application's event loop & window-manager."""
    def __init__(self, scale: float= 0.66, logto: TextIO | None = None, log_verbose: int = 0):
        QApplication.__init__(self, argv)

        QMainWindow.__init__(self, 0)

        self.dimensions = self.screenspace.width() * scale, self.screenspace.height() * scale

        self.logto = logto

        self.central = None


    def event(self, event: QWidget) -> bool:
        """process an event."""
        if self.logto:
            # TODO: Log application events
            pass
        
        return super(AVPApplication, self).event(event)
    

    def notify(self, reciever: QObject, event: QEvent):
        """notify a widget, or QObject, of an event."""
        if self.logto:
            # TODO: Log application notifications
            pass

        return super(AVPApplication, self).notify(reciever, event)

    
    @property
    def logto(self) -> TextIO:
        return stdout
    

    @logto.setter
    def logto(self, stream: TextIO):
        stdout = stream
    
    
    @property
    def space(self):
        """dynamically fetch the space available on the primary screen."""
        return self.screen().availableSize()
    

    @property
    def dimensions(self):
        """dynamically fetch the application window's width & height."""
        return self.width(), self.height()
    
    
    @dimensions.setter
    def dimensions(self, wxh: tuple[int | float, int | float]):
        """dynamically set the application window's width & height."""
        self.resize(
            wxh[0] if not wxh[0] == -1 else self.width(), 
            wxh[1] if not wxh[1] == -1 else self.height()
        )
    

    def render(self):
        self.show()
    
    
    def execute(self):
        return self.exec()