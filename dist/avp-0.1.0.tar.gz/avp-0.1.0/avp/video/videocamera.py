import cv2


class VideoCamera:
    def __init__(self):
        pass
