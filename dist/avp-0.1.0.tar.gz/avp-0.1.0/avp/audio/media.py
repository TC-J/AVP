from pathlib import Path

import tempfile
from tempfile import _TemporaryFileWrapper

import contextlib

from os import devnull

from numpy import ndarray
import numpy as np

import librosa

import resampy

import audio_extract

import soundfile

from avp.audio.signal import signal


def copyout_audio_from_media_container(media_source_filepath: Path | str, audio_copy_destination: str | Path):
    """extract a copy of the audio from a media container, out to a seperate file"""
    src = Path(media_source_filepath)

    dest = Path(audio_copy_destination)

    to_format = dest.suffix[1:-1]

    audio_extract.extract_audio(input_path=src, output_path=dest, output_format=to_format)


def copyin_audio_from_media_container(media_source_filepath: Path | str) -> tempfile._TemporaryFileWrapper:
    """extract a copy of the audio from a media container, to an in-memory-only file-object"""
    src = Path(media_source_filepath)

    tmpfile = tempfile.NamedTemporaryFile()

    with open(devnull, "w") as f, contextlib.redirect_stdout(f):
        audio_extract.extract_audio(input_path=src, output_path=tmpfile.name, output_format="wav")

    return tmpfile


