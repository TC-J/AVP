import math

import numpy as np

from avp.audio import signal

from avp.audio.util import calculate_frame_hop

import scipy

import scipy.signal


class tone:
    def __init__(self):
        pass


class harmonic:
    def __init__(self, sig: signal, f_res: int, t_res: float, limit_mib: float | int = 512):

        pass