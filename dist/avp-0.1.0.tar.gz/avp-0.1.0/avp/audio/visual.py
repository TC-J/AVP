import math

from matplotlib.axes import Axes


from matplotlib.font_manager import FontProperties

from avp.audio.signal import signal

import python_speech_features

from python_speech_features import hz2mel, mel2hz, get_filterbanks

import scipy

import matplotlib.pyplot as plt

import numpy as np

from typing import List, Tuple

import scipy.signal

import io


def plot(sig: signal):
    t = np.arange(0, sig.duration, sig.period)

    for channel in range(sig.channels):
        plt.plot(t, sig.ndarray[:, channel], label=f"Channel {channel}")

    plt.title(f"Signal Plot")

    plt.xlabel("Time (s)")

    plt.ylabel("Amplitude")

    plt.legend()

    return plt.gcf()

