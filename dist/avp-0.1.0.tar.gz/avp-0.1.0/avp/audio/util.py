import numpy as np

from matplotlib.figure import Figure

import io


def calculate_frame_hop(
    sampling_rate: int,
    sample_width: int,
    time_resolution: float, 
    frequency_resolution: int,
    duration: float,
    limit_mib: int | float = 512
    ) -> tuple[float, float, float]:
    limit = limit_mib * 1024 ** 2

    frame_size = sampling_rate / frequency_resolution

    nr_frames = duration / time_resolution

    memory_per_frame = frame_size * sample_width

    total_mem = nr_frames * memory_per_frame

    if total_mem > limit:
        nr_frames = limit / memory_per_frame

        return duration / nr_frames, nr_frames, total_mem

    else:
        return time_resolution, nr_frames, total_mem



    