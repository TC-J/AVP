from sqlite3 import Time
from typing import Any, Self

import math
from warnings import warn

import numpy as np

from numpy.typing import NDArray

from numpy import ndarray

import matplotlib.pyplot as plt

import scipy

import scipy.signal

import scipy.fft

import resampy

import soundfile

import pydub

import librosa

import pyloudnorm

import python_speech_features

class signal(ndarray):
    def __new__(cls, input_array, sr=1, period=None, duration=None, sample_width: int | None = None, channels_are_in_column_major: bool = False):
        obj = np.asarray(input_array).view(cls)

        if len(list(obj.shape)) == 1:
            obj = np.expand_dims(obj, 1)

        else:
            obj = obj if not channels_are_in_column_major else obj.T.view(cls)

        obj._samplewidth = sample_width if sample_width else obj.itemsize

        obj._sr = sr

        obj._period = period 

        obj._duration = duration

        obj._norm = None

        return obj


    def __array_finalize__(self, obj: None | NDArray[Any], *numpy_args, **numpy_kwargs) -> np.ndarray:
        if obj is None: return

        self._samplewidth = getattr(obj, "_samplewidth", None)

        self._bitdepth = getattr(obj, "_bitdepth", None)

        self._sr = getattr(obj, "_sr", None)

        self._period = getattr(obj, "_period", None)

        self._duration = getattr(obj, "_duration", None)

        self._norm = getattr(obj, "_norm", None)

        return super().__array_finalize__(self, *numpy_args, **numpy_kwargs)
    

    def __getitem__(self, key):
        if isinstance(key, int | float):
            return signal (
                input_array=super().__getitem__(self._signal_index(key)),
                sr=self.sr,
                duration=self.duration,
                sample_width=self._samplewidth
            )

        elif isinstance(key, slice):
            return signal(
                input_array=super().__getitem__(self._signal_slice(key)),
                sr=self.sr,
                duration=self.duration,
                sample_width=self._samplewidth
            )

        else:
            return signal(
                input_array=super().__getitem__(self._signal_key(key)),
                sr=self.sr,
                duration=self.duration,
                sample_width=self._samplewidth
            )
        

    def __setitem__(self, key, value):
        super().__setitem__(self._signal_key(key), value)


    def __str__(self) -> str:
        if not self._duration:

            return super().__str__()

        dur = f"{self.duration:.9f}s" if self.duration >= 1.0 else f"{self.duration * 1000:.6f}ms" if self.duration >=0.001 else f"{self.duration * 100_000:.3f}us" if self.duration >= 0.000001 else f"{self.duration * 100_000_000}ns"

        T = f"{self.period:.9f}s" if self.period>= 1.0 else f"{self.period* 1000:.6f}ms" if self.period>=0.001 else f"{self.period* 100_000:.3f}us" if self.period>= 0.00001 else f"{self.period* 100_000_000:.0f}ns"

        return f"Audio Signal(\n\tDuration = {dur},\n\tTimestamp Delta (T) = {T},\n\tSamples (N) = {self.N},\n\tSample Rate = {self.sr} Hz, Sample Width = {self._samplewidth} bytes,\n\tBit Rate = {self.bitrate} bits/s,\n\tChannels = {self.channels},\n* ** Audio Channels' Amplitude Vector in Column-Major** *\n{super().__str__()}\n)"


    def __repr__(self) -> str:
        return f"<signal@{id(self)}, N={self.N}, T={self.period}, sr={self.sr}, channels={self.channels}, duration={self.duration}, samplewidth={self._samplewidth}, bitrate={self.bitrate}>"


    def _signal_index(self, key: float | int):
        """allows floats to represent time-indexes converted to a sample-index based on the period."""
        return key if isinstance(key, int) else int(key // self.period)
    
    
    def _signal_slice(self, key: slice) -> slice:
        """adjust the slice to have the signal's default values as well as including floats for time-converted sample indexes"""
        return slice(
            0 if not key.start else self._signal_index(key.start)
            , self.N if not key.stop else self._signal_index(key.stop)
            , 1 if not key.step else self._signal_index(key.step)
        )

    
    def _signal_key(self, key) -> tuple:
        """returns the key to index the signal samples with floats as time-indexes which find the sample-index based on the period."""
        args = list()

        for k in list(key):
            if isinstance(k, float | int):
                args.append(self._signal_index(k))

            else:
                args.append(k if not isinstance(k, slice) else self._signal_slice(k)) 

        return tuple(args)
    

    @property
    def in_column_major(self):
        return self.T


    @property
    def dynamic_range(self):
        """dynamic range"""
        pass
    

    @property
    def as_numpy(self) -> np.ndarray:
        return self.view(np.ndarray)
    
    @property
    def ndarray(self) -> np.ndarray:
        return self.as_numpy
    
    @property
    def channels(self) -> int:
        return self.shape[-1]
    
    
    @property
    def N(self) -> int:
        return self.shape[0]


    @property
    def period(self) -> float:
        return 1 / self.sr if not self._period else self._period
    
    
    @property
    def sr(self):
        return self._sr if self._sr else 1 / self._period
    

    @property
    def duration(self) -> float:
        return self.N * self.period

    
    @property
    def time_domain(self) -> ndarray:
        return np.arange(0, self.duration, self.period)


    @property
    def sample_width(self) -> int:
        return self._samplewidth


    @property
    def bitdepth(self) -> int:
        return self._samplewidth * 8

    
    @property
    def bitrate(self) -> int:
        return self.channels * self.bitdepth * self.sr


    @property
    def peak(self) -> int | float:
        return np.max(np.abs(self))
    

    @property
    def floor(self)-> int | float:
        return np.min(np.abs(self.as_numpy.astype(np.int64)))
    

    @property
    def rms_norm(self):
        pass
    

    @property
    def peak_norm(self):
        pass

    
    @property
    def lufs_norm(self):
        pass
    

    def to_dbfs(self) -> Self:
        print(self.rms)
        return signal(
            input_array=self.rms,
            sr=self.sr, 
            sample_width=self._samplewidth
        )
    

    def to_lufs(self) -> Self:
        return signal(
            [pyloudnorm.Meter(self.sr).integrated_loudness(self[::, channel]) for channel in range(self.channels)],
            self.sr
        )


    def into_mono(self) -> Self:
        return signal(input_array=(self.sum(axis=1) / self.channels).T.astype(self.dtype), sr=self.sr)


    def save(self, fpath: str):
        pydub.AudioSegment(
            data=self.channels_column_major.tobytes(),
            frame_rate=self.sr,
            sample_width=self._samplewidth,
            channels=self.channels
        ).export(fpath)
    
    
    def load(fpath: str, start_time: float | None = None, duration: float | None = None, *args, **kwargs):
        audio: pydub.AudioSegment = pydub.AudioSegment.from_file(fpath, *args, start_second=start_time, duration=duration, **kwargs)

        samples = np.array(audio.get_array_of_samples()).reshape((-1, audio.channels))

        return signal(input_array=samples, sr=audio.frame_rate, sample_width=audio.sample_width, channels_are_in_column_major=False)
